from fastapi import FastAPI
from pydantic import BaseModel  
import pickle
import json
import uvicorn
import pandas as pd

app= FastAPI()

class leadscore_input(BaseModel):
    TotalVisits:float
    Total_Time_Spent_on_Website: float
    Page_Views_Per_Visit : float
    Lead_Origin : str
    Last_Activity : str
    What_is_your_current_occupation : str
    Tags : str
    Last_Notable_Activity : str

def process(df):
    df['TotalVisits']=(df['TotalVisits'][0]-3.441558)/4.902408
    df['Total_Time_Spent_on_Website']=(df['Total_Time_Spent_on_Website'][0]- 490.595527)/548.647589
    df['Page_Views_Per_Visit']=(df['Page_Views_Per_Visit'][0]- 2.356091)/ 2.061836

    df['Lead_Origin_Lead_Add_Form']=df['Lead_Origin'].map(lambda x:1 if x=='Lead_Add_Form' else 0)

    df['Last_Activity_SMS_Sent']=df['Last_Activity'].map(lambda x:1 if x=='SMS_Sent' else 0)

    df['What_is_your_current_occupation_Working_Professional']=df['What_is_your_current_occupation'].map(lambda x:1 if x=='Working_Professional' else 0)

    df['Tags_Closed_by_Horizzon']=df['Tags'].map(lambda x:1 if x== 'Closed_by_Horizzon' else 0)

    df['Tags_Ringing']=df['Tags'].map(lambda x:1 if x=='Ringing' else 0)

    df['Tags_Will_revert_after_reading_the_email']=df['Tags'].map(lambda x:1 if x=='Will_revert_after_reading_the_email' else 0)

    df['Last_Notable_Activity_SMS_Sent']=df['Last_Notable_Activity'].map(lambda x:1 if x=='SMS_Sent' else 0)

    return df    

#  loading the saved model....
loaded_model=pickle.load(open('/home/ubuntu/Desktop/ml_model/app/model.pkl','rb'))

@app.get('/')
def home():
    return {'message':'welcome to lead_score predict model'}

# lead score input values posted through this api
@app.post('/leadscore_prediction/')
def leadscore_pred(input_parameters: leadscore_input):


    # input parameters posted to our PI in the form of json
    input_data = input_parameters.json()

    #  convert input into dictionary
    input_dictionary = json.loads(input_data)
    df = pd.DataFrame.from_dict(input_dictionary,orient='index').T

    df1=process(df)

    
    

    # dict contain key-value pairs,convert all dictionary inputs into list
    TotalVisits = df1['TotalVisits'][0]

    Total_Time_Spent_on_Website = df1['Total_Time_Spent_on_Website'][0]

    Page_Views_Per_Visit = df1['Page_Views_Per_Visit'][0]

    Lead_Origin_Lead_Add_Form = df1['Lead_Origin_Lead_Add_Form'][0]

    Last_Activity_SMS_Sent = df1['Last_Activity_SMS_Sent'][0]

    What_is_your_current_occupation_Working_Professional = df1['What_is_your_current_occupation_Working_Professional'][0]

    Tags_Closed_by_Horizzon = df1['Tags_Closed_by_Horizzon'][0]

    Tags_Ringing = df1['Tags_Ringing'][0]

    Tags_Will_revert_after_reading_the_email = df1['Tags_Will_revert_after_reading_the_email'][0]

    Last_Notable_Activity_SMS_Sent = df1['Last_Notable_Activity_SMS_Sent'][0]
    
    # final data passing to the model

    input_list=[TotalVisits,
    Total_Time_Spent_on_Website,
    Page_Views_Per_Visit,
    Lead_Origin_Lead_Add_Form,
    Last_Activity_SMS_Sent,
    What_is_your_current_occupation_Working_Professional,
    Tags_Closed_by_Horizzon,
    Tags_Ringing,
    Tags_Will_revert_after_reading_the_email,
    Last_Notable_Activity_SMS_Sent]

    # prediction

    prediction=loaded_model.predict([input_list])


    if prediction[0]==0:
        pred_msg='lead was not converted'

    else:
        pred_msg='lead was converted'

    lead_score=int(loaded_model.predict_proba([input_list])[:,1][0]*100)

    if lead_score>=50:
        hot_or_cold='lead is hot'

    else:
        hot_or_cold= 'lead is cold'


    return {'Prediction message': pred_msg,
    'Lead is hot or cold': hot_or_cold
    }

if __name__ == "__main__":
 uvicorn.run(app, port=8000)