from fastapi import FastAPI
from pydantic import BaseModel  
import pickle
import json
import uvicorn

app= FastAPI()


@app.get('/')
def home():
    return {'message':'welcome to lead_score predict model'}


if __name__ == "__main__":
 uvicorn.run(app, port=8000)